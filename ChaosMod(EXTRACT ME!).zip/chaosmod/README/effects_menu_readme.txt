The effects menu (enableable in the config utility) allows you to turn to turn on any effect you desire.
The effects are sorted in alphabetical order and effects disabled in the config utility are filtered out.

Navigation:

- Arrow Up / Down: Move up or down
- Enter: Trigger effect
- Backspace: Exit the menu