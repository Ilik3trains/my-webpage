The Twitch integration feature allows you to connect the mod to twitch chat and let viewers vote for effects that occur in the mod.

-- How To Enable It --

Start the config utility and go to the twitch tab. Read the text at the top and tick the checkbox below it.
Next you'll have to enter your Twitch channel name, your Twitch username (or which account you want to show chat messages with, make sure they have mod rights) and an OAuth token (using tools like https://twitchapps.com/tmi/ ).
Make sure to check out the other options too and customize them to your liking.

If everything went well you should have a big red text saying "Twitch Voting Enabled!" on startup.

-- How To Use It --

Twitch chat will now be able to vote for one of the shown effects every time a voting round starts.
Voting can be done by typing one of the numbers shown either in the chat by the bot or on-screen (in-game or OBS overlay) after the mod mentions three voteable effects in chat.

Depending on if you enabled the proportional voting system:
- If not, the effect with the most votes will be triggered as soon as the timer bar is filled.
- If yes, votes will affect the likelyhood of one of the shown effects triggering instead and the mod itself will choose one of the effects at the end of the vote round.

While voters can not vote multiple times in a round, they may change their vote in the current round by voting again.

If the "Random Effect" option is enabled, viewers will be able to vote for a 4th option each voting round to let the mod choose an effect itself.

If you get an error popup by the mod when starting up the game with Twitch integration enabled, make sure to read the error message and verify your entered Twitch credentials.

-- OBS Overlay --

If you wish to use the OBS overlay, choose it in the config utility first.

Afterwards, add a new Browser Source in OBS itself, tick "Local file" and select the index.html file inside the twitchOverlay as the file.

The overlay should be visible at the position of your choice once the mod is running and the first voting round starts.